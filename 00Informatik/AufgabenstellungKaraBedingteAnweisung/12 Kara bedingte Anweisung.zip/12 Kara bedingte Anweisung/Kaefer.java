import ch.aplu.jgamegrid.*;
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import java.util.Random;

public class Kaefer extends Actor{
    public Kaefer(){
        super(true,"images/kara.png");
    }

    public void act(){

    }
    

    private int zufall(int grenze){
        Random r=new Random();
        return r.nextInt(grenze);
    }

    /*
     * Methoden: 
     * move(): geht einen Schritt
     * turnLeft(): dreht sich um 90° nach links
     * turnRight(): dreht sich um 90° nach rechts
     * 
     * pickLeaf(): nimmt ein Blatt auf, das unter ihm liegt
     * putLeaf(): legt ein Blatt ab, wenn das Feld leer ist
     * 
     * Boolean-Methoden:
     * isOnLeaf(), isTreeFront(), isTreeLeft(), isTreeRight(), isPolzFront()
     */

    /**
     * In der act()-Methode wird das Verhalten des Kaefers programmiert.
     * Sie wird beim Klicken von Step einmal, beim Klicken von run wiederholt ausgeführt.
     */

    private static final int DIRECTION_RIGHT = 0;
    private static final int DIRECTION_DOWN = 90;
    private static final int DIRECTION_LEFT = 180;
    private static final int DIRECTION_UP = 270;

    public void move() {
        // Check for a tree
        if (isTreeFront()) {
            showWarning("Kara can't move because of a tree!",
                "Kara kann sich nicht bewegen wegen einem Baum!");
            return;
        }

        // Check for a mushroom
        Pilz mushroomFront = (Pilz) getObjectFront(
                this.getIntDirection(), 1, Pilz.class);
        if (mushroomFront != null) {
            // Check if the mushroom could be pushed to the next field
            if (getObjectFront(this.getIntDirection(), 2, Baum.class) == null
            && getObjectFront(this.getIntDirection(), 2,
                Pilz.class) == null) {
                // Push the mushroom
                moveActor(mushroomFront, this.getIntDirection());
                // Check if the mushroom is now on a leaf
                mushroomFront.updateImage();
            } else {
                // Could not push the mushroom
                showWarning(
                    "Kara can't move because he can't push the mushroom!",
                    "Kara kann sich nicht bewegen, da er den Pilz nicht schieben kann!");
                return;
            }
        }

        // Kara can move
        moveActor(this, this.getIntDirection());
        refresh();
        delay();
    }

    /**
     * Kara turns left by 90 degrees <br>
     * <i>Kara dreht sich um 90° nach links</i>
     */
    public void turnLeft() {
        this.turn(-90);
        refresh();
        delay();
    }

    /**
     * Kara turns right by 90 degrees <br>
     * <i>Kara dreht sich um 90° nach rechts</i>
     */
    public void turnRight() {
        this.turn(90);
        refresh();
        delay();
    }

    /**
     * Kara puts down a leaf <br>
     * <i>Kara legt ein neues Kleeblatt an die Position, auf der er sich befindet</i>
     */
    public void putLeaf() {
        if (!isOnLeaf()) {
            Blatt blatt = new Blatt();
            getWorld().addActor(blatt, this.getLocation());
            refresh();
            delay();
        } else {
            showWarning("Kara can't put a leaf on top of another leaf!",
                "Kara kann kein Kleeblatt auf ein Feld legen, auf dem schon eines ist!");
        }
    }

    /**
     * Kara picks up a leaf <br>
     * <i>Kara entfernt ein unter ihm liegendes Kleeblatt</i>
     */
    public void pickLeaf() {
        Actor blatt = getWorld().getOneActorAt(this.getLocation(), Blatt.class);
        if (blatt != null) {
            getWorld().removeActor(blatt);
            refresh();
            delay();
        } else {
            showWarning("There is no leaf that Kara could remove here!",
                "Kara kann hier kein Blatt auflesen!");
        }
    }

    /**
     * Kara checks if he stands on a leaf <br>
     * <i>Kara schaut nach, ob er sich auf einem Kleeblatt befindet</i>
     * 
     * @return true if Kara stands on a leaf, false otherwise
     */
    public boolean isOnLeaf() {
        return getWorld().getOneActorAt(this.getLocation(), Blatt.class) != null;
    }

    /**
     * Kara checks if there is a tree in front of him <br>
     * <i>Kara schaut nach, ob sich ein Baum vor ihm befindet</i>
     * 
     * @return true if there is a tree in front of Kara, false otherwise
     */
    public boolean isTreeFront() {
        return getObjectFront(this.getIntDirection(), 1, Baum.class) != null;
    }

    /**
     * Kara checks if there is a tree on his left side <br>
     * <i>Kara schaut nach, ob sich ein Baum links von ihm befindet</i>
     * 
     * @return true if Kara has a tree on his left, false otherwise
     */
    public boolean isTreeLeft() {
        return getObjectFront(modulo(this.getIntDirection() - 90, 360), 1,
            Baum.class) != null;
    }

    /**
     * Kara checks if there is a tree on his right side <br>
     * <i>Kara schaut nach, ob sich ein Baum rechts von ihm befindet</i>
     * 
     * @return true if Kara has a tree on his right, false otherwise
     */
    public boolean isTreeRight() {
        return getObjectFront(modulo(this.getIntDirection() + 90, 360), 1,
            Baum.class) != null;
    }

    /**
     * Kara checks if there is a mushroom in front of him <br>
     * <i>Kara schaut nach, ob er einen Pilz vor sich hat</i>
     * 
     * @return true if a mushroom is in front of a Kara, false otherwise
     */
    public boolean isPilzFront() {
        return getObjectFront(this.getIntDirection(), 1, Pilz.class) != null;
    }

    /**
     * Stops the simulation cycle (the act()-method is finished first) <br>
     * <i>Stoppt die Simulation (die act()-Methode wird noch bis unten ausgefuehrt)</i>
     */
    protected void stop() {
        getWorld().doPause();
    }

    /*----- END OF STANDARD KARA METHODS! BELOW ARE JUST SOME HELPER METHODS ----- */
    /**
     * Shows a popup with a warning message containing both the english or
     * german message.
     */
    protected void showWarning(String englishMessage, String germanMessage) {
        String message = "<html>" + englishMessage + "<p><i>" + germanMessage
            + "</i></html>";

        Object[] options = { "OK", "Exit Program" };
        int choice = JOptionPane.showOptionDialog(null, message, "Warning",
                JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null,
                options, options[0]);

        if (choice == 1) {
            // Emergency stop.
            getWorld().stopGameThread();
            System.exit(0);
        } else {
            // Stop. This will still finish the act()-method.
            getWorld().doPause();
        }
    }

    /**
     * Returns Kara's World.
     * 
     * @return
     */
    protected GameGrid getWorld() {
        return this.gameGrid;
    }

    /**
     * Finds an object in the specified direction.
     * 
     * @param direction
     *            the direction in which to look for the object
     * @param steps
     *            number of cells to look ahead (1 means the next field, etc.)
     * @param clazz
     *            the (actor) class to look for
     * @return the object that was found or null if none was found
     */
    protected Object getObjectFront(int direction, int steps, Class<?> clazz) {
        int x = this.getX();
        int y = this.getY();

        // Change x und y depending on the direction
        switch (direction) {
            case DIRECTION_RIGHT:
            x = modulo((x + steps), getWorld().getNbHorzCells());
            break;

            case DIRECTION_DOWN:
            y = modulo((y + steps), getWorld().getNbVertCells());
            break;

            case DIRECTION_LEFT:
            x = modulo((x - steps), getWorld().getNbHorzCells());
            break;

            case DIRECTION_UP:
            y = modulo((y - steps), getWorld().getNbVertCells());
            break;

            default: // Not a valid direction
            return null;
        }

        Actor actor = getWorld().getOneActorAt(new Location(x, y), clazz);

        if (actor != null) {
            return actor;
        } else {
            return null;
        }
    }

    /**
     * Moves the actor one step in the specified direction.
     * 
     * @param actor
     *            the actor to be moved
     * @param direction
     *            the direction to move
     */
    private void moveActor(Actor actor, int direction) {
        switch (direction) {
            case DIRECTION_RIGHT:
            actor.setLocation(new Location(modulo((actor.getX() + 1), getWorld()
                        .getNbHorzCells()), actor.getY()));
            break;

            case DIRECTION_DOWN:
            actor.setLocation(new Location(actor.getX(), modulo((actor.getY() + 1),
                        getWorld().getNbVertCells())));
            break;

            case DIRECTION_LEFT:
            actor.setLocation(new Location(modulo((actor.getX() - 1), getWorld()
                        .getNbHorzCells()), actor.getY()));
            break;

            case DIRECTION_UP:
            actor.setLocation(new Location(actor.getX(), modulo((actor.getY() - 1),
                        getWorld().getNbVertCells())));
            break;

            default: // Not a valid direction
            break;
        }
    }

    /**
     * A special modulo operation that never returns a negative number. This is
     * necessary to always stay inside the grid of the world.
     * <p>
     * The Java modulo operation would return -1 for something like -1%10, but
     * we would need 9.
     * <p>
     * Note: Depending on the programming language, the modulo operation for
     * negative numbers is defined differently.
     * 
     * @param a
     *            the first operand
     * @param b
     *            the second operand
     * @return the result of the modulo operation, always positive
     */
    private int modulo(int a, int b) {
        return (a % b + b) % b;
    }

    /**
     * Refreshes the current game situation (repaint background, tiles, actors).
     * This is necessary because we want to refresh inside an act instead of
     * only after the act method finishes.
     */
    private void refresh() {
        getWorld().refresh();
    }

    /**
     * Delays for one simulation period (depending on the speed slider).
     */
    private void delay() {
        GameGrid.delay(getWorld().getSimulationPeriod());
    }

}
