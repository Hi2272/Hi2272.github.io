import ch.aplu.jgamegrid.Actor;

/**
 * A tree is a barrier for Kara. Kara can neither move through nor push trees.
 * 
 * @author Marco Jakob (http://edu.makery.ch)
 */
public class Baum extends Actor {
	
	/**
	 * Constructor.
	 */
	public Baum() {
		super("images/baum.png");
	}
	
	@Override
	public String toString() {
		// used for "inspect"
		return "Baum";
	}
}