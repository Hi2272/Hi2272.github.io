import ch.aplu.jgamegrid.*;
import java.awt.Color;

public class Welt extends GameGrid{
    
    public Welt(){
        super(10,10,30,Color.green);
        for (int i=0;i<30;i++){
            
            this.addActor(new Baum(),this.getRandomEmptyLocation());
        }
        this.addActor(new Kaefer(),this.getRandomEmptyLocation());
        this.show();
    }

}
