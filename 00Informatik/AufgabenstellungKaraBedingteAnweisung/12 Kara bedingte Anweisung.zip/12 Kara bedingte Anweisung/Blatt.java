import ch.aplu.jgamegrid.Actor;

/**
 * A Blatt can be put and removed by Kara.
 * 
 * @author Marco Jakob (http://edu.makery.ch)
 */
public class Blatt extends Actor {

	/**
	 * Constructor.
	 */
	public Blatt() {
		super("images/blatt.png");
	}
	
	@Override
	public String toString() {
		// used for "inspect"
		return "Blatt";
	}
}