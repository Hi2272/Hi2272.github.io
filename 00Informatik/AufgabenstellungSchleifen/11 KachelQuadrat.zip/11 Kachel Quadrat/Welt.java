import ch.aplu.jgamegrid.*;
import java.awt.Color;

public class Welt extends GameGrid
{
    public Welt()
    {
        super(10, 10, 60, Color.red);
        addActor(new Kachel("gruen"),new Location(0,0));
        addActor(new Kachel("gruen"),new Location(1,0));
        addActor(new Kachel("gruen"),new Location(2,0));
        addActor(new Kachel("gruen"),new Location(3,0));
        addActor(new Kachel("gruen"),new Location(4,0));
        addActor(new Kachel("gruen"),new Location(5,0));
        addActor(new Kachel("gruen"),new Location(6,0));
        addActor(new Kachel("gruen"),new Location(7,0));
        addActor(new Kachel("gruen"),new Location(8,0));
        addActor(new Kachel("gruen"),new Location(9,0));
        
        this.show();
    }
}

    