import ch.aplu.jgamegrid.*;

public class Kachel extends Actor
{
  public Kachel()
  {
    super("sprites/gruen.png");
  }
  
  public Kachel(String farbe){
      super("sprites/"+farbe+".png");
    }
}
